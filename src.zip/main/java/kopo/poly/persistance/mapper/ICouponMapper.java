package kopo.poly.persistance.mapper;

public interface ICouponMapper {
}
