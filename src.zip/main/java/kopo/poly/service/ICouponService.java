package kopo.poly.service;

public interface ICouponService {
}
