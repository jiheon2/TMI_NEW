package kopo.poly.service;

public interface ICommentService {
}
